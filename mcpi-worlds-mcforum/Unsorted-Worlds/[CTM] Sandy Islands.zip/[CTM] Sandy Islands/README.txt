Thanks for downloading my Sandy Islands CTM map! I hope you will enjoy it!
I made this map for your pleasure, and I would enjoy seeing some LP's about this map. This map is made for around 3-5 hours of playing time.

blafbello is the original creator of this map, and if you use this map, give him some credit!
===========================================================================================================
[CTM] SANDY ISLANDS
===========================================================================================================
Your goal is to collect all six wool blocks, and bring them safely to the wool monument, located in the sandstone pyramid. There are some rules
which you have to keep in mind:
- No dyeing wool blocks
- No hex editing blocks. There's a cobblestone generator in the cave if you really want it
- Take only one wool block of each color with you. In that way you have another chance of getting the wool if you die (there are two wool blocks in each wool chamber)
- You are allowed to craft. Swords and pickaxes are very usefull, expecially in the cave

You have to collect the following wool blocks:
- yellow
- orange
- magenta
- red
- light blue
- blue

There's also a score system. There are 32 birchwood spread over the map. Some of them are really hard to find, but one should be able to collect at least 10.
If you really need to, you can craft wooden planks of a birch wood.

Post a screenshot of you at the monument with all wool blocks placed in the monument, and all birchwood in your hotbar.

Thanks for reading, and HAVE FUN!

blafbello